package z1;

public class Automati {

	   protected String s1, s2, s3;
	   protected int k;
	   protected String s4;
	public Automati(String s1, String s2, String s3, int k, String s4) {
		super();
		this.s1 = s1;
		this.s2 = s2;
		this.s3 = s3;
		this.k = k;
		this.s4 = s4;
	}
	
	public Automati() {
		super();
	}

	public String getS1() {
		return s1;
	}
	public void setS1(String s1) {
		this.s1 = s1;
	}
	public String getS2() {
		return s2;
	}
	public void setS2(String s2) {
		this.s2 = s2;
	}
	public String getS3() {
		return s3;
	}
	public void setS3(String s3) {
		this.s3 = s3;
	}
	public int getK() {
		return k;
	}
	public void setK(int k) {
		this.k = k;
	}
	public String getS4() {
		return s4;
	}
	public void setS4(String s4) {
		this.s4 = s4;
	}
	@Override
	public String toString() {
		return "Automati s1=" + s1 + ", s2=" + s2 + ", s3=" + s3 + ", k=" + k + ", s4=" + s4 + "\n";
	}
}

package z1;

public class Kraj {
   protected String pozicija;
   protected String automat;
public Kraj(String pozicija, String automat) {
	super();
	this.pozicija = pozicija;
	this.automat = automat;
}
public String getPozicija() {
	return pozicija;
}
public void setPozicija(String pozicija) {
	this.pozicija = pozicija;
}
public String getAutomat() {
	return automat;
}
public void setAutomat(String automat) {
	this.automat = automat;
}
@Override
public String toString() {
	return "(" + pozicija + ") " + automat + "\n";
}
}

package z1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class ListA {
   protected ArrayList<Automati>a=new ArrayList<Automati>();
   protected ArrayList<Kraj>b=new ArrayList<Kraj>();
   protected ArrayList<Xelement>x=new ArrayList<Xelement>();
public ListA(ArrayList<Automati> a, ArrayList<Kraj> b, ArrayList<Xelement> x) {
	super();
	this.a = a;
	this.b = b;
	this.x = x;
}
  public void impAut(String file) {
	   BufferedReader in= null;
	   String l;
	   try {
		in= new BufferedReader(new FileReader(file));
		while((l=in.readLine())!=null) {
			String[] delovi=l.split(" ");
			String s1=delovi[0];
			String s2=delovi[1];
			String s3=delovi[2];
			int k=Integer.parseInt(delovi[3]);
			String pozicija=delovi[4];
			a.add(new Automati(s1,s2,s3,k,pozicija));
		}
	   }catch(Exception e) {
		   e.printStackTrace();
	   }finally {
		   if(in!=null) {
		   try {
			  in.close(); 
		   }catch(Exception e) {
			   e.printStackTrace();
		   }
	   }
  }}
  public ArrayList<Kraj> ispisi() {
	  ArrayList<Kraj>lista=new ArrayList<Kraj>();
	  String temp1,temp2;
	   for(int i=1; i<a.size(); i++) {
		  while(a.get(i).getK()==a.get(0).getK()) {
			//  System.out.println();
			  String poz=a.get(i).getS4();
			 // System.out.println("0-"+poz);
			  temp1=a.get(i).getS1();
			  temp2=a.get(0).getS1();
			if(!(temp1.equals(temp2))){
			//	System.out.println(temp1+"-"+temp2+" ");
				String l2=temp2+"-"+temp1;
				String l1="0-"+i;
				Kraj k1=new Kraj(l1,l2);
				b.add(k1);
			}
			 temp1=a.get(i).getS2();
			 temp2=a.get(0).getS2();
			 if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp2+"-"+temp1;
					String l1="0-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
			 temp1=a.get(i).getS3();
			 temp2=a.get(0).getS3();
			 if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1="0-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
		  break;}
	   }
	   for(int i=2; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(1).getK()) {
		//		  System.out.println();
				  String poz=a.get(i).getS4();
		//		  System.out.println("1-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(1).getS1();
				if(!(temp1.equals(temp2))){
		//			System.out.println(temp1+"-"+temp2+" ");
					String l2=temp2+"-"+temp1;
					String l1="1-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
					
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(1).getS2();
				 if(!(temp1.equals(temp2))){
		//				System.out.println(temp1+"-"+temp2+" ");
						String l2=temp2+"-"+temp1;
						String l1="1-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
				 }
				 temp1=a.get(i).getS3();
				 temp2=a.get(1).getS3();
				 if(!(temp1.equals(temp2))){
		//				System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="1-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
				 }
			  break;}
		   }
	   for(int i=3; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(2).getK()) {
		//		  System.out.println();
				  String poz=a.get(i).getS4();
		//		  System.out.println("2-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(2).getS1();
				if(!(temp1.equals(temp2))){
		//			System.out.println(temp1+"-"+temp2+" ");
					String l2=temp2+"-"+temp1;
					String l1="2-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(2).getS2();
				 if(!(temp1.equals(temp2))){
		//				System.out.println(temp1+"-"+temp2+" ");
						String l2=temp2+"-"+temp1;
						String l1="2-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(2).getS3();
				 if(!(temp1.equals(temp2))){
		//				System.out.println(temp1+"-"+temp2+" ");
						String l2=temp2+"-"+temp1;
						String l1="2-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
			  break;}
		   }
	   for(int i=4; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(3).getK()) {
		//		  System.out.println();
				  String poz=a.get(i).getS4();
		//		  System.out.println("3-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(3).getS1();
				if(!(temp1.equals(temp2))){
		//			System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1="3-"+i;;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(3).getS2();
				 if(!(temp1.equals(temp2))){
		//				System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="3-"+i;;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(3).getS3();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="3-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
			  break;}
		   }
	   for(int i=5; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(4).getK()) {
			//	  System.out.println();
				  String poz=a.get(i).getS4();
			//	  System.out.println("4-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(4).getS1();
				if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp2+"-"+temp1;
					String l1="4-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(4).getS2();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp2+"-"+temp1;
						String l1="4-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(4).getS3();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp2+"-"+temp1;
						String l1="4-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
			  break;}
		   }
	   for(int i=6; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(5).getK()) {
			//	  System.out.println();
				  String poz=a.get(i).getS4();
			//	  System.out.println("5-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(5).getS1();
				if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1="5-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(5).getS2();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="5-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(5).getS3();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="5-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
			  break;}
		   }
	        for(int i=7; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(6).getK()) {
			//	  System.out.println();
				  String poz=a.get(i).getS4();
			//	  System.out.println("6-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(6).getS1();
				if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1="6-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(6).getS2();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="6-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(6).getS3();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="6-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
			  break;}}
			  for(int i=8; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(7).getK()) {
			//	  System.out.println();
				  String poz=a.get(i).getS4();
			//	  System.out.println("7-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(7).getS1();
				if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1="7-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(7).getS2();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="7-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(7).getS3();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="7-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
					break;}
			  }
			  for(int i=9; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(8).getK()) {
			//	  System.out.println();
				  String poz=a.get(i).getS4();
			//	  System.out.println("8-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(8).getS1();
				if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1="8-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(8).getS2();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="8-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(8).getS3();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="8-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
					break;}}
					for(int i=9; i<a.size(); i++) {
			  while(a.get(i).getK()==a.get(8).getK()) {
			//	  System.out.println();
				  String poz=a.get(i).getS4();
			//	  System.out.println("8-"+poz);
				  temp1=a.get(i).getS1();
				  temp2=a.get(8).getS1();
				if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1="8-"+i;
					Kraj k1=new Kraj(l1,l2);
					b.add(k1);
				}
				 temp1=a.get(i).getS2();
				 temp2=a.get(8).getS2();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="8-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}
				 temp1=a.get(i).getS3();
				 temp2=a.get(8).getS3();
				 if(!(temp1.equals(temp2))){
			//			System.out.println(temp1+"-"+temp2+" ");
						String l2=temp1+"-"+temp2;
						String l1="8-"+i;
						Kraj k1=new Kraj(l1,l2);
						b.add(k1);
					}break;}}
			  lista=b;
			  return lista;
  }
  
  public ArrayList<Kraj> ispisi2() {
	  ArrayList<Kraj>lista=new ArrayList<Kraj>();
	  String temp1,temp2;
	   for(int i=0; i<a.size()-10; i++) {
		  for(int j=i+1; j<a.size()-9;j++) {
		   while(a.get(j).getK()==a.get(i).getK()) {
			//  System.out.println();
			  String poz=a.get(j).getS4();
			 // System.out.println(i+"-"+poz);
			  temp1=a.get(j).getS1();
			  temp2=a.get(i).getS1();
			if(!(temp1.equals(temp2))){
			//	System.out.println(temp1+"-"+temp2+" ");
				String l2=temp2+"-"+temp1;
				String l1=i+"-"+j;
				Kraj k1=new Kraj(l1,l2);
				if ((b.contains(k1))==true) {}else {
				b.add(k1);}
			}
			 temp1=a.get(j).getS2();
			 temp2=a.get(i).getS2();
			 if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp2+"-"+temp1;
					String l1=i+"-"+j;
					Kraj k1=new Kraj(l1,l2);
					if ((b.contains(k1))==true) {}else {
						b.add(k1);}
				}
			 temp1=a.get(j).getS3();
			 temp2=a.get(i).getS3();
			 if(!(temp1.equals(temp2))){
			//		System.out.println(temp1+"-"+temp2+" ");
					String l2=temp1+"-"+temp2;
					String l1=i+"-"+j;
					Kraj k1=new Kraj(l1,l2);
					if ((b.contains(k1))==true) {}else {
						b.add(k1);}
				}
			 break;}}
	   }lista=b;
	   return lista;
  }
  public ArrayList<Xelement> xlista(){
	    ArrayList<Xelement>x=new ArrayList<Xelement>();
	    Xelement xe=new Xelement();
	    for(int i=1; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(0).getK()) {
				  String poz=a.get(i).getS4();
				    poz="0-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=2; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(1).getK()) {
				  String poz=a.get(i).getS4();
				    poz="1-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=3; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(2).getK()) {
				  String poz=a.get(i).getS4();
				    poz="2-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=4; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(3).getK()) {
				  String poz=a.get(i).getS4();
				    poz="3-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=5; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(4).getK()) {
				  String poz=a.get(i).getS4();
				    poz="4-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=6; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(5).getK()) {
				  String poz=a.get(i).getS4();
				    poz="5-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=7; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(6).getK()) {
				  String poz=a.get(i).getS4();
				    poz="6-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=8; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(7).getK()) {
				  String poz=a.get(i).getS4();
				    poz="7-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }
	    for(int i=9; i<a.size(); i++) {
			  if(a.get(i).getK()!=a.get(8).getK()) {
				  String poz=a.get(i).getS4();
				    poz="8-"+poz;
				  xe=new Xelement(poz);
				  x.add(xe);
			  }
	    }    
	  return x;
  }
  
  public void expAut(String file, String aut) {
	  BufferedWriter out= null;
	  try {
		  out = new BufferedWriter(new FileWriter(file));
		  out.write(aut);
	  }catch(Exception e) {
		  e.printStackTrace();
	  }finally {
		 if(out!=null) {
			 try {
				 out.close();
			 }catch(Exception e) {
				 e.printStackTrace();
			 }
		 }
	  }
  }
  
  public String toString() {
	  String r="";
	  for (Automati automati : a) {
		  r+=automati+"\n";
	}
	  return r;
  }
  
  public static void main(String[] args) {
	   ArrayList<Automati>lista=new ArrayList<Automati>();
	   ArrayList<Kraj>lista2=new ArrayList<Kraj>();
	   ArrayList<Kraj>lista3=new ArrayList<Kraj>();
	   ArrayList<Xelement>lista4=new ArrayList<Xelement>();
	   ListA a= new ListA(lista,lista3, lista4);
	   a.impAut(args[0]);
	   int h=lista.size();
	   lista2=a.ispisi();
	   lista3=a.ispisi2();
	   String aut=lista3.toString();
	   a.expAut("Resenje3.txt",aut);
	   lista4=a.xlista();
	 //   System.err.println(lista3);
	    for(int q=0; q<2;q++) { 
	    for(int i=0;i<lista3.size();i++) {
		   char s1,s2;
		   s1=lista3.get(i).getAutomat().charAt(1);
		   s2=lista3.get(i).getAutomat().charAt(4);
		
		   for(int j=0; j<lista4.size();j++) { //prolazi kroz listu precrtanih
		      char s3, s4;
		      s3=lista4.get(j).getPozicija().charAt(0);
		      s4=lista4.get(j).getPozicija().charAt(2); //da li ima u precrtanim
			if((s1==s3 && s2==s4) || (s1==s4 && s2==s3)) {
		      String s=lista3.get(i).getPozicija();   //sacuvaj poziciju precrtanog
			 for(int n=0; n<lista3.size();n++) {       //prodji jos jednom za sve iste pozicije
				if(lista3.get(n).getPozicija().equals(s)) {
				//	System.err.println("nema"+s);
					lista3.remove(n);}
			 }lista3.remove(i);               //izbaci ga ovde da string s ne izgubi vrednost
		   }
		  }}}
   for(int i=0;i<lista3.size()-1;i++) {
	 for(int j=i+1;j<lista3.size();j++) {   
	  char s1,s2,p1,p2;
	   s1=lista3.get(i).getPozicija().charAt(2);
	   s2=lista3.get(j).getPozicija().charAt(0);
	   p1=lista3.get(i).getPozicija().charAt(0);
	   p2=lista3.get(j).getPozicija().charAt(2);
	   if(s1==s2) {
		   String l=p1+"-"+p2;
		   for(int k=0; k<lista3.size();k++) {
			   if(lista3.get(k).getPozicija().equals(l)) {
				  String x=p1+"-"+s1+"-"+p2;
				  Kraj k1=new Kraj(x,"A"+p1);
				  int z=lista3.size()-1;
				  if(!(lista3.get(z).getPozicija().equals(x))) {
				  lista3.add(k1);
					System.out.println(k1);
					break;}
		   }}
	   }
	 }}// System.err.println(lista3);
      char s1,s2,s3,g;  
      int z= lista3.size()-1;
	g=lista3.get(z).getAutomat().charAt(1);
		g++;
       s1=lista3.get(z).getPozicija().charAt(0);
       s2=lista3.get(z).getPozicija().charAt(2);
       s3=lista3.get(z).getPozicija().charAt(4);
       for(int i=0;i<lista3.size();i++) {   
    		  char p1;
    		   p1=lista3.get(i).getPozicija().charAt(0);
        if(p1!=s1 && p1!=s2 && p1!=s3) {
        	String q=lista3.get(i).getPozicija();
        	  String o="A"+g;
        	Kraj k1=new Kraj(q,o);
			  int z1=lista3.size()-1;
			  if(!(lista3.get(z1).getPozicija().equals(q))) {
		      lista3.add(k1);
			System.out.println(k1);
			 break;}
        }
       }
       char s4,s5;  
       int z2= lista3.size()-1;
        s4=lista3.get(z2).getPozicija().charAt(0);
        s5=lista3.get(z2).getPozicija().charAt(2);
        
       for(int i=0;i<lista3.size();i++) {   
 		  char p1;
 		   p1=lista3.get(i).getPozicija().charAt(0);
     if(p1!=s1 && p1!=s2 && p1!=s3 && p1!=s4 && p1!=s5) {
     	String q=lista3.get(i).getPozicija();
		g++;
     	  String o="A"+g;
     	Kraj k1=new Kraj(q,o);
			  int z1=lista3.size()-1;
			  if(!(lista3.get(z1).getPozicija().equals(q))) {
		      lista3.add(k1);
			System.out.println(k1);
			 break;}
     }
    } 
	char s6,s7;  
        int z3= lista3.size()-1;
        s6=lista3.get(z3).getPozicija().charAt(0);
        s7=lista3.get(z3).getPozicija().charAt(2);
        
        char p1='0';
       for(int i=0;i<h-1;i++) {   
              p1++;
     if(p1!=s1 && p1!=s2 && p1!=s3 && p1!=s4 && p1!=s5 && p1!=s6 && p1!=s7) {
		g++;
     	  String o="A"+g;
     	  String q=Character.toString(p1);
     	Kraj k1=new Kraj(q,o);
     	lista3.add(k1);
	System.out.println(k1);
     }
    }   
	 //   System.out.println(lista3);
	   String out2=lista3.toString();
	   a.expAut("Resenje4.txt", out2);
	   
}}
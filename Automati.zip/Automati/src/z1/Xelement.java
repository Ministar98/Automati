package z1;

public class Xelement {
   protected String pozicija;
   
   public Xelement(String pozicija) {
	   super();
	   this.pozicija=pozicija;
   }
   
   public Xelement() {
	super();
	pozicija="s";
   }

public String getPozicija() {return pozicija;}
   public void setPozicija(String s) {pozicija=s;}
   
   public String toString() {
	   String s="";
	    s+=pozicija;
	   return s;
   }
}
